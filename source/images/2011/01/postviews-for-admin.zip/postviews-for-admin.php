<?php
/*
Plugin Name: PostViews for Admin
Plugin URI: http://fairyfish.net/2009/07/23/postviews-admin/
Description: �� WordPress ��̨��־�б�ҳ����ʾ�����
Version: 0.1
Author: Denis
*/
	add_filter('manage_posts_columns', 'postviews_admin_add_column');
	function postviews_admin_add_column($columns){
		$columns['views'] = __('Views');
		return $columns;
	}
	add_action('manage_posts_custom_column','postviews_admin_show',10,2);
	function postviews_admin_show($column_name,$id){
		if ($column_name != 'views')
			return;	
		$post_views = get_post_meta($id, "views",true);
		echo $post_views;
	}
	add_action('admin_head', 'postviews_admin_css');
	function postviews_admin_css(){
	?>
	<style type="text/css">
	.fixed .column-views {
		width: 6em;
	}
	</style>
<?php } ?>