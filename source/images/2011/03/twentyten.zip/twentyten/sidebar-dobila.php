<?php
/**
 * The Sidebar containing the primary and secondary widget areas.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>

		<div id="dobila-side" class="widget-area" role="complementary">
			<ul class="xoxo">

		<!--
			<li id="search" class="widget-container widget_search">
				<?php //get_search_form(); ?>
				</li>
		-->
			
			<!-- Random Posts -->
			<li id="dobila-random" class="widget-container">
				<h3 class="widget-title">Random Posts</h3>
				<ul>
				<?php $randomPosts = $wpdb->get_results("SELECT ID, post_title FROM $wpdb->posts WHERE ID != $post->ID AND post_status = 'publish' AND post_type = 'post' ORDER BY rand() LIMIT 10");
				foreach($randomPosts as $randomPost) { ?>
					<li><a href="<?php echo get_permalink($randomPost->ID) ?>" title="<?php echo $randomPost->post_title; ?>"><?php echo $randomPost->post_title; ?></a></li>
				<?php } ?>
				</ul>
			</li>

			<!-- Relative Posts -->
			<li id="dobila-relative" class="widget-container">
				<h3 class="widget-title">Relative Posts</h3>
				<ul>
				<?php $tags = wp_get_post_tags($post->ID);
				foreach ($tags as $tagg) {
						$tags_id[] = $tagg->term_id;
				};
				if ($tags) {
					$args=array(
					'tag__in' => $tags_id,
					'post__not_in' => array($post->ID),
					'showposts'=>10,
					'caller_get_posts'=>1
				);
				$my_query = new WP_Query($args);
				if( $my_query->have_posts() ) { while ($my_query->have_posts()) : $my_query->the_post(); ?>
					<li><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
				<?php endwhile; } } ?>
				</ul>
			</li>

			<!-- Recent Comments -->
			<li id="dobila-comment" class="widget-container">
				<h3 class="widget-title">Recent Comments</h3>
				<ul>
				<?php $sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,12) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND comment_author != 'dobila' AND post_password = '' ORDER BY comment_date_gmt DESC LIMIT 10"; $comments = $wpdb->get_results($sql); 
				foreach ($comments as $comment1) { ?>
				<li>
				<?php echo $comment1->comment_author; ?> says <br> <a href="<?php echo get_permalink($comment1->ID) ?>#comment-<?php echo $comment1->comment_ID ?>" title="on <?php echo $comment1->post_title ?>"><?php echo $comment1->com_excerpt; ?></a>
				</li>
				<?php }; ?>
				</ul>
			</li>

			<li id="meta" class="widget-container">
				<h3 class="widget-title"><?php _e( 'Meta', 'twentyten' ); ?></h3>
				<ul>
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<?php wp_meta(); ?>
				</ul>
			</li>

		</ul>
		</div><!-- #primary .widget-area -->

