=== wp-utf8-excerpt ===
Tags: post, excerpt, homepage, archive
Tested up to: 2.9
Stable tag: trunk

This plugin generates a better excerpt for multibyte language users (Chinese, for example). Besides, it keeps the html tags in the excerpt. 
适合中文的摘要插件，可设置是否保留文章中的格式标签，如字体、颜色、链接、图片等。

== Description ==
= Main features of the plugin: =
1. It supports multibyte language (such as Chinese). It will not produce gibberish as some other excerpt plugins do.
2. The html tags in the original posts, i.e., the font styles, colors, hyperlinks, pictures and such are preserved in the excerpt.
3. For better readability, it displays 300 characters for each post on the homepage and 150 characters for each post on archive pages.

主要特点：
1，支持多字节语言（如中文），不会产生乱码。
2，摘要可保留文章中的格式标签，如字体、颜色、链接、图片等（需保留的标签可在后台设置）。
3，首页每篇文章显示300字，存档页面每篇文章显示150字（字数可设置）。

= Installation =
1. Unzip and upload the `wp-utf8-excerpt` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. In your theme directory, edit the index.php file by changing 

		<?php the_content(); ?>

to

		<?php
			if (is_single() or is_page()) {
				the_content();
			} else {
				the_excerpt();
			} 
		?>

安装：
1，解压到/wp-content/plugins/目录
2，在插件页面激活插件
3，修改主题的index.php文件，把

		<?php the_content(); ?>

改成

		<?php
			if (is_single() or is_page()) {
				the_content();
			} else {
				the_excerpt();
			} 
		?>

注意：有些主题在the_content()中还有一些字，比如the_content(’Continue Reading »’)，这种要把整句话换掉。有些主题用了其他文件来控制存档页面，如category.php、archive.php等，如有必要，请对这些文件也做修改。

== Frequently Asked Questions ==
常见问题：
1，为什么安装了插件之后无效？

答：请看“安装”部分，确认对主题文件进行了正确的修改。

2，想/不想在摘要中显示某些标签，比如图片、视频，怎么办？

答：进入后台设置页面（Settings——Excerpt），修改Allow these HTML tags中的内容。
默认设置显示图片，不想显示图片的话就把<img>删掉。
默认设置不显示视频，想显示视频的话就加入视频的标签，各个视频网站不一样，有可能是<embed>或<object>或其他，查看插入视频的代码就知道了。
其他标签以此类推。

3，为什么用了<!--more-->标签还是输出全文了？

答：因为你的全文太短了……如果全文比设定的摘要字数长的话，<!--more-->标签还是有效的。
		
== Changelog ==
0.5.1	fix a small bug about the <!--more--> tag

0.5		add the option to set the HTML tags you'd like to preserve

0.4.2.1 fix a small bug

0.4.2	fix a bug caused by the bug fixed in 0.4.1

0.4.1	fix a "missing argument for mb_strlen" bug

0.4		add an option page. Now you can set the excerpt length in Settings->Excerpt.

0.3.4   add support for the <!--more--> tag; give the "read more" link a "read-more" class so that one can control its style via css

0.3.3	fix: display the "read more" link even if the excerpt is given by the user

0.3.2	fix a bug in the "read more" link (the permalink)

0.3.1	add a "read more" link

0.3 	release
